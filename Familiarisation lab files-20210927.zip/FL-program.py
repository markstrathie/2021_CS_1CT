# A program to be used in the Familiarisation Lab
# Quintin

data = open( "FL-data.txt" )

nextLine = data.readline()

while nextLine != "":
    numberOfRepeats = int( nextLine[ : -1 ] )

    for i in range( numberOfRepeats ):
        print( "x", end = "" )
    print()
    
    nextLine = data.readline()

